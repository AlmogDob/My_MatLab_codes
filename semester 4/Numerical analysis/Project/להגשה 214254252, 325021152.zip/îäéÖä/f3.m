function [f3] = f3(z2)
% Third function in ODE system
f3 = z2;
end