function [f1] = f1(x2)
% First function in ODE system
f1 = x2;
end