helicopter = "UH1N";
if "UH1N" == helicopter
    mo = 99.58289; % [kg]
    R = 7.32; % [m]
    Ad = 168.3341; % [m^2]
    c = 0.59; % [m]
    L = 7;  % [-]
    Nb = 2; % [-]
    Sigma = 0.051312; % [-]
    Rotor_Speed = 324; % [RPM]
    Vt = 248.3617; % [m/s]
    Delta_Z = 2; % [m]
    Rt = 1.3; % [m]
    Ad_t = 5.309292; % [m^2]
    Ct = 0.292; % [m]
    Nb_t = 2; % [-]
    Sigma_t = 0.142995; % [-]
    TR_Speed = 1662; % [RPM]
    Vt_t = 226.2575; % [m/s]
    l_t = 8.7; % [m]
    Delta_Zt = 2; % [m]
    V23 = 0.0046; % [-]
    Max_TO_Weight = 11200*0.4536; % [kg]
    Empty_Weight = 6600*0.4536; % [kg]
    Cw_min = 0.002311; % [-]
    Cw_max = 0.003922; % [-]
    Pmax = 1300; % [Kw]
    P1_NR100 = 9.66; % [Kw] - 1% P at 100% NR
    Torque1 = 284.7105; % [N*m] - 1% torque
    Sb = 4; % [m^2] - Drag Area
    Sht = 2.5; % [m^2] - ht Area
    Delta_Xht = 5.5; % [-]
    Alpha_ht = 3.5; % [-]
    Tao_RPM = 4.3; % [s] - RPM loss const
    
    Omega = Rotor_Speed*2*pi/60; % [rad/sec]
    Omega_t = TR_Speed*2*pi/60; % [rad/sec]
    
elseif "Puma" == helicopter

    mo = 68; % [kg]
    R = 7.50; % [m]
    Ad = 177; % [m^2]
    c = 0.54; % [m]
    L = 9.85;  % [-]
    Nb = 4; % [-]
    Sigma = 0.09; % [-]
    Rotor_Speed = 265; % [RPM]
    Vt = 208; % [m/s]
    Delta_Z = 2.1; % [m]
    Rt = 1.56; % [m]
    Ad_t = 7.65; % [m^2]
    Ct = 0.15; % [m]
    Nb_t = 5; % [-]
    Sigma_t = 0.15; % [-]
    TR_Speed = 1279; % [RPM]
    Vt_t = 209; % [m/s]
    l_t = 9; % [m]
    Delta_Zt = 1.6; % [m]
    V23 = 0.0009; % [-]
    Max_TO_Weight = 15430*0.4536; % [kg]
    Empty_Weight = 7800*0.4536; % [kg]
    Cw_min = 0.0037; % [-]
    Cw_max = 0.0073; % [-]
    Pmax = 2350; % [Kw]
    P1_NR100 = 15.3; % [Kw] - 1% P at 100% NR
    Torque1 = 551.3; % [N*m] - 1% torque
    Sb = 4; % [m^2] - Drag Area
    Sht = 1.3; % [m^2] - ht Area
    Delta_Xht = 9; % [-]
    Alpha_ht = 3; % [-]
    Tao = 2.6; % [s] - RPM loss const
    
    Omega = Rotor_Speed*2*pi/60; % [rad/sec]
    Omega_t = TR_Speed*2*pi/60; % [rad/sec]

elseif "Lynx" == helicopter

    mo = 50; % [kg]
    R = 6.4; % [m]
    Ad = 129; % [m^2]
    c = 0.39; % [m]
    L = 7.06;  % [-]
    Nb = 4; % [-]
    Sigma = 0.08; % [-]
    Rotor_Speed = 340; % [RPM]
    Vt = 229; % [m/s]
    Delta_Z = 1.3; % [m]
    Rt = 1.11; % [m]
    Ad_t = 3.84; % [m^2]
    Ct = 0.18; % [m]
    Nb_t = 4; % [-]
    Sigma_t = 0.21; % [-]
    TR_Speed = 1844; % [RPM]
    Vt_t = 214; % [m/s]
    l_t = 7.66; % [m]
    Delta_Zt = 1.1; % [m]
    V23 = 0.0045; % [-]
    Max_TO_Weight = 11750*0.4536; % [kg]
    Empty_Weight = 7225*0.4536; % [kg]
    Cw_min = 0.0039; % [-]
    Cw_max = 0.0064; % [-]
    Pmax = 1500; % [Kw]
    P1_NR100 = 13.2; % [Kw] - 1% P at 100% NR
    Torque1 = 369.7; % [N*m] - 1% torque
    Sb = 3; % [m^2] - Drag Area
    Sht = 1.2; % [m^2] - ht Area
    Delta_Xht = 7.66; % [-]
    Alpha_ht = 3; % [-]
    Tao = 2.6; % [s] - RPM loss const
    
    Omega = Rotor_Speed*2*pi/60; % [rad/sec]
    Omega_t = TR_Speed*2*pi/60; % [rad/sec]
end

Cd0 = 0.014;
Cd0_t = 0.014;
ki = 0.8;
ki_t = 0.5;
L_Temp = 6.5*10^(-3); % [K/m]

Sd = 2.3368*(12.68476+3.88747*1.5)/2;
Sd_Bar = Sd/Ad;
Sb_Bar = Sb/Ad;

% Sea-level atmospheric conditions
T_SL = 288; % [k]
P_SL = 101325; % [pa]
Rho_SL = 1.225; % [kg/m^3]

Weight = (Max_TO_Weight + Empty_Weight)/2; % [kg]
Cw = (Weight*9.81)/(Rho_SL*(Vt^2)*Ad);

F = Vt/sqrt(9.81*R);
m_bar = Cw*F^2;

gx_bar = 0.17;
gy_bar = 0.3;
gz_bar = 0.3;
gxz_bar = 0.08;

Ix_bar = m_bar*gx_bar^2;
Iy_bar = m_bar*gy_bar^2;
Iz_bar = m_bar*gz_bar^2;
Ixz_bar = m_bar*gxz_bar^2;